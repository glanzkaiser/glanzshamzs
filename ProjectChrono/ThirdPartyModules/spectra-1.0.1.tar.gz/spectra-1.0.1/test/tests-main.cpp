// tests-main.cpp
#define CATCH_CONFIG_MAIN
#include "catch.hpp"